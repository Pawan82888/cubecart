<?php
/**
 * CubeCart v6
 * ========================================
 * CubeCart is a registered trade mark of CubeCart Limited
 * Copyright CubeCart Limited 2014. All rights reserved.
 * UK Private Limited Company No. 5323904
 * ========================================
 * Web:   http://www.cubecart.com
 * Email:  sales@cubecart.com
 * License:  GPL-3.0 http://opensource.org/licenses/GPL-3.0
 */
if(!defined('CC_INI_SET')) die('Access Denied');
$module		= new Module(__FILE__, $_GET['module'], 'admin/index.tpl', true);
$page_content = $module->display();

if (!extension_loaded('mcrypt') || !function_exists('mcrypt_module_open')) {
	$GLOBALS['main']->setACPWarning('Mcrypt library missing from server required to encrypt credit card data!');
}